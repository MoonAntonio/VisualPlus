﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VisualPlus.Toolkit.Dialogs;

namespace $rootnamespace$
{
    /// <summary>The <see cref="$safeitemname$"/> entry point.</summary>
    public partial class $safeitemname$ : VisualForm
    {
        /// <summary>Initializes a new instance of the <see cref="$safeitemname$" /> class.</summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
